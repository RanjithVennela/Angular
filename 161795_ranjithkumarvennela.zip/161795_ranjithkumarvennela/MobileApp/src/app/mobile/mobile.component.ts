import { Component, OnInit } from '@angular/core';

import {Mobile} from './mobile'
import { MobileService } from '../mobile.service';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css'],
  providers:[MobileService]
})
export class MobileComponent implements OnInit {
  
  mob1:number;
 tmp:number;
  mobiles:Mobile[] = [];  // Creating array for storing the mobile data
  samArr:Mobile[]=[];
  mobile = new Mobile();  //creating instance of mobile class
  idMobiles:any=[];

  left:number=0;
  right:number=0;

  constructor(private iteration:MobileService) { }  // import mobileservice to extract data from service class

  ngOnInit() { 
    // Getting the data from mobileService class
    
    this.iteration.getAllProduct().subscribe((data:Mobile[])=>this.mobiles=data);

  }

  delete(mob:Mobile) // delete the data using mobile object 
  {
      this.mobiles = this.mobiles.filter(x => x.id!=mob.id)  //using filter method delete the particular mobile data 
  }

  sortId()  // sort the data using id of the mobile
  {
    this.left=0;
    this.right=0;
    this.mobiles.map(x=>
      {                               // pushing all ids into an array to sort the original array using ids
        this.idMobiles.push(x.id)
      })
  
      this.idMobiles.sort()      //sort the array of ids

      for(let t=0;t<=this.mobiles.length;t++)
      { 
        for(let a of this.mobiles)                    // checking the ids and pushing into another array similar to mobiles
        {
            if(a.id==this.idMobiles[this.left])
            {
              this.samArr[this.right]=a;
              this.right++
            }
        }
      this.left++
    }
      this.left=0

      this.mobiles.map(m=>{
      this.mobiles[this.left]=this.samArr[this.left]   // assigning the sample sorted array of objects to original array of objects(mobiles).
      this.left++
    })
    console.log(this.mobiles);
  this.idMobiles=[]
  }

  sortName()   // sort the data using name of the mobile
  {         
    this.left=0;
    this.right=0;
      this.mobiles.map(x=>
        {                         
                // pushing name of the mobiles into an array to sort the original array using ids
          this.idMobiles.push(x.mobileName)
        })
    
        this.idMobiles.sort()      //sort the array of names
  
        for(let t=0;t<=this.mobiles.length;t++)
        { 
          for(let a of this.mobiles)                    // checking the names and pushing into another array similar to mobiles
          {
              if(a.mobileName==this.idMobiles[this.left])
              {
                this.samArr[this.right]=a;
                this.right++
              }
          }
        this.left++
      }
        this.left=0
  
        this.mobiles.map(m=>{
        this.mobiles[this.left]=this.samArr[this.left]   // assigning the sample sorted array of objects to original array of objects(mobiles).
        this.left++
      })
    this.idMobiles=[]
      console.log(this.mobiles);
    }

  sortPrice()               // sort the data using price of the mobile
  {
    this.left=0;
    this.right=0;
      this.mobiles.map(x=>
        {       
                                // pushing price of the mobiles into an array to sort the original array using ids
          this.idMobiles.push(Number(x.mobilePrice));
        })
        console.log(this.idMobiles);                //sorting
        
        for(let i=0;i<this.idMobiles.length;i++)
        {
          for(let j=i+1;j<this.idMobiles.length;++j)
          {
            
            if(this.idMobiles[i] > this.idMobiles[j])
            {
              
              this.mob1=this.idMobiles[i]
             this.idMobiles[i] = this.idMobiles[j];
              this.idMobiles[j]=this.mob1;
            }
           
          }
        }
        
        for(let t=0;t<=this.mobiles.length;t++)
        { 
          for(let a of this.mobiles)                    // checking the prices and pushing into another array similar to mobiles
          {
              if(a.mobilePrice==this.idMobiles[this.left])
              {
                this.samArr[this.right]=a;
                this.right++;
              }
          }
        this.left++;
      }
        
        this.left=0;
  
        this.mobiles.map(m=>{
        this.mobiles[this.left]=this.samArr[this.left] ; // assigning the sample sorted array of objects to original array of objects(mobiles).
        this.left++;
      })
    this.idMobiles=[];
    console.log(this.mobiles);
  }
}


  




