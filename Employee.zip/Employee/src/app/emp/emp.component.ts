import { Component, OnInit } from '@angular/core';
import { Emp } from '../employee';

import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {
  emp : Emp = new Emp();
  emp1 : Emp = new Emp();
  emps : Emp[] = [];
  emp2 : Emp = new Emp();
  constructor() { }

  ngOnInit() {
    
  }
  
  addDetails()
  {
      this.emps.push(this.emp);
      alert(this.emp.empId + " " + this.emp.empName+ " "+ this.emp.empSal+ " "+this.emp.empDept);
      this.emp = new Emp();
  } 
  updateEmployee(e : Emp)
  {
    Object.assign(this.emp1,e);
    Object.assign(this.emp2,e);
  }
  updateEmployee1()
  {
    const empss: Emp[] = [];
    this.emps.forEach(values => {
      if(values.empId == this.emp2.empId)
      {
        empss.push(this.emp1);
      }
      else{
        empss.push(values);
      }
    })
    this.emps = empss;
    this.emp1 = new Emp();
  }
  deleteEmployee(e : Emp)
  {
      this.emps = this.emps.filter(x=>x.empId != e.empId)
  }
}
