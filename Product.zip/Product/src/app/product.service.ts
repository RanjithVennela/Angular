import { Injectable } from '@angular/core';
import { Product } from './product';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
@Injectable()
export class ProductService {
  counter:number = 0;
  prods : Product[] = []
  constructor(private http:Http) { }
  addProds(p : Product): Observable<Product[]>
  {
    return this.http.post("http://localhost:3000/Prods",p).map((response:Response)=><Product[]>response.json());
  }
  getAllProds():Observable<Product[]>
  {

    return this.http.get("http://localhost:3000/Prods").map((response:Response)=><Product[]>response.json());
  }
  removeProduct1(id:number) : Observable<Product[]>
  {
    return this.http.delete("http://localhost:3000/Prods/" + id).map((response:Response)=><Product[]>response.json()).catch(this.handleError);
  }
  handleError(error:Response)
  {
    console.error(error);
    return Observable.throw(error);
  } 
  updateProduct1(p:Product):Observable <Product[]>
  {
      return this.http.put("http://localhost:3000/Prods/" +p.id,p).map((response:Response)=><Product[]>response.json());
  }
}
