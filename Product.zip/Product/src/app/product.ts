export class Product {
    id:number;
    proName:string;
    prodQty:number;
}
