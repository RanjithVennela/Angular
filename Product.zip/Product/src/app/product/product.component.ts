import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { error } from 'protractor';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductService]
})
export class ProductComponent implements OnInit {
  prods : Product[] = [];
  pro : Product = new Product();
  constructor(private  productService : ProductService) { }

  ngOnInit() {
    this.productService.getAllProds().subscribe((proData) => this.prods = proData);
  }

    dispDetails()
    {
      if(!this.pro.id)
      {
        this.productService.addProds(this.pro).subscribe((proData) => this.productService.getAllProds().subscribe((proData) => this.prods = proData));
        this.pro = new Product();
      }
      else
      {
        this.productService.updateProduct1(this.pro).subscribe((proData) => this.productService.getAllProds().subscribe((proData) => this.prods = proData));
      }
    }
    removeProduct(id:number)
    {
        this.productService.removeProduct1(id).subscribe((proData) => this.productService.getAllProds().subscribe((proData) => this.prods = proData), (error) => 
        {
          console.error(error);

        })
        
        console.log(JSON.stringify(this.prods));
    }
    updateProduct1(p : Product)
    {
      Object.assign(this.pro,p);
      
    }
}
