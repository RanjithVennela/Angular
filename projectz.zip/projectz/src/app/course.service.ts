import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Courses } from './courses';
import 'rxjs/add/observable/of';
@Injectable()
export class CourseService {
courseArr:Courses[];
cArray:Courses[]=[{
  courseName:"HTML",
  courseDuration:10
},
{
courseName:"JavaScript",
  courseDuration:20},
  {
  courseName:"CSS",
    courseDuration:5}];
  constructor(private http:HttpClient) { }
 
  getCourseData():Observable<any>{
    return  this.http.get("./assets/courses.json")
  }

  addCourse(e:Courses)
  {
    console.log(e);
    this.cArray.push(e);
  }
  getCourse():Observable<Courses[]>
  {
    return Observable.of(this.cArray);
  }
}
