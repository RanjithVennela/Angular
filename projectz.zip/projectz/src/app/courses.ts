export class Courses {
    courseName:String;
    courseDuration:Number;
}
